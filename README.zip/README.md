# Ruota Armeria Paleto

